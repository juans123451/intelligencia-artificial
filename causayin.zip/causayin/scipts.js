
        // Base de datos de productos (la mantienes igual)
const productsDB = [
    { id: 1, name: "Leche", category: "lacteos", store: "Supermercado union", price: 3.50, unit: "litro" },

// Base de datos de productos (ejemplo)

            { id: 1, name: "Leche", category: "lacteos", store: "Supermercado union", price: 3.50, unit: "litro" },
            { id: 2, name: "Leche", category: "lacteos", store: "Supermercado mercado central", price: 3.20, unit: "litro" },
            { id: 3, name: "Leche", category: "lacteos", store: "Supermercado laikakota", price: 3.80, unit: "litro" },
            { id: 4, name: "Pan", category: "panaderia", store: "plaza vea", price: 2.00, unit: "unidad" },
            { id: 5, name: "Pan", category: "panaderia", store: "Supermercado Belalvita", price: 1.80, unit: "unidad" },
            { id: 6, name: "Pan", category: "panaderia", store: "Supermercado Central", price: 2.20, unit: "unidad" },
            { id: 7, name: "Huevos", category: "lacteos", store: "Supermercado union", price: 4.50, unit: "docena" },
            { id: 8, name: "Huevos", category: "lacteos", store: "Supermercado Bellavista", price: 4.20, unit: "docena" },
            { id: 9, name: "Huevos", category: "lacteos", store: "Supermercado Centro", price: 4.80, unit: "docena" },
            { id: 10, name: "Arroz", category: "granos", store: "Supermercado union", price: 5.00, unit: "kg" },
            { id: 11, name: "Arroz", category: "granos", store: "Supermercado Bellavista", price: 4.75, unit: "kg" },
            { id: 12, name: "Arroz", category: "granos", store: "Supermercado Central", price: 5.25, unit: "kg" },
            { id: 13, name: "Pollo", category: "carnes", store: "Supermercado union", price: 8.50, unit: "kg" },
            { id: 14, name: "Pollo", category: "carnes", store: "Supermercado Bellavista", price: 8.20, unit: "kg" },
            { id: 15, name: "Pollo", category: "carnes", store: "Supermercado Central", price: 8.80, unit: "kg" },
            { id: 16, name: "Tomate", category: "vegetales", store: "Supermercado union", price: 3.00, unit: "kg" },
            { id: 17, name: "Tomate", category: "vegetales", store: "plaza vea", price: 2.80, unit: "kg" },
            { id: 18, name: "Tomate", category: "vegetales", store: "Supermercado Central", price: 3.20, unit: "kg" },
            { id: 19, name: "Cebolla", category: "vegetales", store: "Supermercado union", price: 2.50, unit: "kg" },
            { id: 20, name: "Cebolla", category: "vegetales", store: "Supermercado Bellavista", price: 2.30, unit: "kg" },
            { id: 21, name: "Cebolla", category: "vegetales", store: "Supermercado Centra", price: 2.70, unit: "kg" },
            { id: 22, name: "Pasta", category: "granos", store: "Supermercado plaza vea", price: 1.50, unit: "paquete" },
            { id: 23, name: "Pasta", category: "granos", store: "Supermercado Bellavista", price: 1.30, unit: "paquete" },
            { id: 24, name: "Pasta", category: "granos", store: "Supermercado Central", price: 1.70, unit: "paquete" },{ id: 25, name: "Carne de res", category: "carnes", store: "Supermercado union", price: 18.50, unit: "kg" },
            { id: 26, name: "Carne de res", category: "carnes", store: "Supermercado mercado central", price: 17.80, unit: "kg" },
            { id: 27, name: "Carne de res", category: "carnes", store: "Supermercado laikakota", price: 19.20, unit: "kg" },
{ id: 28, name: "Cerdo", category: "carnes", store: "Supermercado union", price: 12.50, unit: "kg" },
{ id: 29, name: "Cerdo", category: "carnes", store: "Supermercado union ", price: 11.80, unit: "kg" },
{ id: 30, name: "Cerdo", category: "carnes", store: "Supermercado Central", price: 13.20, unit: "kg" },
{ id: 31, name: "Pescado", category: "carnes", store: "Supermercado union", price: 15.00, unit: "kg" },
{ id: 32, name: "Pescado", category: "carnes", store: "Supermercado mercado central", price: 14.50, unit: "kg" },
{ id: 33, name: "Pescado", category: "carnes", store: "Supermercado laikakota", price: 16.20, unit: "kg" },
{ id: 34, name: "Chorizo", category: "carnes", store: "Supermercado union", price: 22.80, unit: "kg" },
{ id: 35, name: "Chorizo", category: "carnes", store: "Supermercado Bellavista", price: 21.50, unit: "kg" },
{ id: 36, name: "Chorizo", category: "carnes", store: "Supermercado Centra", price: 24.00, unit: "kg" },
{ id: 37, name: "Jamón", category: "carnes", store: "Supermercado union", price: 25.00, unit: "kg" },
{ id: 38, name: "Jamón", category: "carnes", store: "Supermercado mercado central", price: 23.80, unit: "kg" },
{ id: 39, name: "Jamón", category: "carnes", store: "Supermercado laikakota", price: 26.50, unit: "kg" },
//{ id: 40, name: "Salchicha", category: "carnes", store: "Supermercado union", price: 8.20, unit: "paquete" },
//{ id: 41, name: "Salchicha", category: "carnes", store: "Supermercado B", price: 7.80, unit: "paquete" },
//{ id: 42, name: "Salchicha", category: "carnes", store: "Supermercado C", price: 8.60, unit: "paquete" },
{ id: 43, name: "Cordero", category: "carnes", store: "Supermercado union", price: 28.50, unit: "kg" },
{ id: 44, name: "Cordero", category: "carnes", store: "Supermercado mercado central", price: 27.20, unit: "kg" },
{ id: 45, name: "Cordero", category: "carnes", store: "Supermercado laikakota", price: 30.00, unit: "kg" },
{ id: 46, name: "Pavo", category: "carnes", store: "Supermercado union", price: 16.80, unit: "kg" },
{ id: 47, name: "Pavo", category: "carnes", store: "Supermercado laikakota", price: 15.90, unit: "kg" },
{ id: 48, name: "Pavo", category: "carnes", store: "Supermercado central", price: 17.50, unit: "kg" },
{ id: 49, name: "Tocino", category: "carnes", store: "Supermercado union", price: 20.00, unit: "kg" },
{ id: 50, name: "Tocino", category: "carnes", store: "Supermercado mercado central", price: 19.20, unit: "kg" },
{ id: 51, name: "Tocino", category: "carnes", store: "Supermercado laikakota", price: 21.50, unit: "kg" },
{ id: 52, name: "Costillas", category: "carnes", store: "Supermercado union", price: 14.50, unit: "kg" },
{ id: 53, name: "Costillas", category: "carnes", store: "Supermercado centras", price: 13.80, unit: "kg" },
{ id: 54, name: "Costillas", category: "carnes", store: "Supermercado laikakota", price: 15.20, unit: "kg" }
        ];


// Algoritmo voraz para optimización de compras (igual)
function greedyShoppingOptimizer(shoppingList) {
    const results = [];
    let totalSavings = 0;

    shoppingList.forEach(item => {
        const matches = productsDB.filter(product => 
            product.name.toLowerCase().includes(item.toLowerCase()) ||
            item.toLowerCase().includes(product.name.toLowerCase())
        );

        if (matches.length > 0) {
            const bestOption = matches.reduce((min, current) => 
                current.price < min.price ? current : min
            );

            const maxPrice = Math.max(...matches.map(m => m.price));
            const savings = maxPrice - bestOption.price;
            totalSavings += savings;

            results.push({
                product: bestOption,
                savings: savings,
                alternatives: matches.length - 1
            });
        }
    });

    return { results, totalSavings };
}

// Procesamiento de lenguaje natural básico (igual)
function processNaturalLanguage(input) {
    const commonProducts = [
        'leche', 'pan', 'huevos', 'arroz', 'pollo', 'tomate', 'cebolla', 'pasta',
        'queso', 'mantequilla', 'yogurt', 'cereales', 'azucar', 'sal', 'aceite', 'carne', 'cerdo' , 'salchicha'
    ];

    const words = input.toLowerCase().split(/[\s,]+/);
    const detectedProducts = [];

    words.forEach(word => {
        commonProducts.forEach(product => {
            if (word.includes(product) || product.includes(word)) {
                if (!detectedProducts.includes(product)) {
                    detectedProducts.push(product);
                }
            }
        });
    });

    if (detectedProducts.length === 0) {
        if (input.includes('desayuno')) {
            detectedProducts.push('leche', 'pan', 'huevos');
        } else if (input.includes('cena') || input.includes('comida')) {
            detectedProducts.push('pollo', 'arroz', 'tomate', 'cebolla');
        } else if (input.includes('pasta') || input.includes('espagueti')) {
            detectedProducts.push('pasta', 'tomate');
        }
    }

    return detectedProducts;
}

function addMessage(message, isUser = false) {
    const chatContainer = document.getElementById('chatContainer');
    const messageDiv = document.createElement('div');
    messageDiv.className = `message ${isUser ? 'user' : 'agent'}`;

    // Para que respete el formato del mensaje-content que tienes en HTML:
    const contentDiv = document.createElement('div');
    contentDiv.className = 'message-content';
    contentDiv.textContent = message;
    messageDiv.appendChild(contentDiv);

    // Añadir cola (tail) para mensajes agente o usuario (según tu CSS)
    const tailDiv = document.createElement('div');
    tailDiv.className = isUser ? 'user-tail' : 'agent-tail';
    messageDiv.appendChild(tailDiv);

    chatContainer.appendChild(messageDiv);
    chatContainer.scrollTop = chatContainer.scrollHeight;
}

function showRecommendations(optimization) {
    const recommendationsDiv = document.getElementById('recommendations');
    const statsDiv = document.getElementById('stats');
    const totalSavingsDiv = document.getElementById('totalSavings');

    recommendationsDiv.innerHTML = '';

    if (optimization.results.length === 0) {
        recommendationsDiv.innerHTML = '<p style="text-align: center; color: #666;">No se encontraron productos en nuestra base de datos.</p>';
        statsDiv.style.display = 'none';
        return;
    }

    optimization.results.forEach(item => {
        const card = document.createElement('div');
        card.className = 'recommendation-card';
        card.innerHTML = `
            <div class="product-name">${item.product.name}</div>
            <div class="store-info">
                <span class="store-name">${item.product.store}</span>
                <span class="price">$${item.product.price.toFixed(2)}</span>
            </div>
            <div class="savings">
                💰 Ahorras $${item.savings.toFixed(2)} vs otras opciones
                ${item.alternatives > 0 ? `• ${item.alternatives} alternativas disponibles` : ''}
            </div>
        `;
        recommendationsDiv.appendChild(card);
    });

    totalSavingsDiv.textContent = `$${optimization.totalSavings.toFixed(2)}`;
    statsDiv.style.display = 'block';
}

async function sendMessage() {
    const input = document.getElementById('userInput');
    const message = input.value.trim();

    if (!message) return;

    addMessage(message, true); // mensaje usuario
    input.value = '';

    document.getElementById('loading').style.display = 'block';

    try {
        // Llamada a la API OpenAI
        const response = await fetch('https://api.openai.com/v1/chat/completions', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': 'Bearer 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'
            },
            body: JSON.stringify({
                model: "gpt-4o-mini",
                messages: [
                    { role: "system", content: "Eres un agente optimizador de compras que ayuda a encontrar los mejores precios en supermercados, basado en una base de datos local." },
                    { role: "user", content: message }
                ],
                temperature: 0.6,
                max_tokens: 400
            })
        });

        if (!response.ok) {
            throw new Error(`Error en la API: ${response.status} ${response.statusText}`);
        }

        const data = await response.json();
        const botReply = data.choices[0].message.content.trim();

        addMessage(botReply);

        // ----------- Extraer productos mencionados en la receta ------------
        // Aquí haremos un filtrado simple: usaremos las palabras clave de commonProducts para detectar
        const commonProducts = [
            'leche', 'pan', 'huevos', 'arroz', 'pollo', 'tomate', 'cebolla', 'pasta',
            'queso', 'mantequilla', 'yogurt', 'cereales', 'azucar', 'sal', 'aceite', 'carne', 'cerdo'
        ];

        // Convertimos respuesta del bot a minúsculas para buscar coincidencias
        const lowerReply = botReply.toLowerCase();

        // Detectamos productos mencionados en la receta
        const productosDetectados = [];
        commonProducts.forEach(product => {
            if (lowerReply.includes(product) && !productosDetectados.includes(product)) {
                productosDetectados.push(product);
            }
        });

        if (productosDetectados.length > 0) {
            const optimization = greedyShoppingOptimizer(productosDetectados);
            showRecommendations(optimization);
        } else {
            // Si no detecta productos en la respuesta, tratar de detectar en el input original
            const fallbackProducts = processNaturalLanguage(message);
            if (fallbackProducts.length > 0) {
                const optimization = greedyShoppingOptimizer(fallbackProducts);
                showRecommendations(optimization);
            } else {
                document.getElementById('recommendations').innerHTML = '';
                document.getElementById('stats').style.display = 'none';
            }
        }
    } catch (error) {
        addMessage('Lo siento, ocurrió un error al comunicarse con el servidor. Por favor intenta más tarde.');
        console.error(error);
        document.getElementById('recommendations').innerHTML = '';
        document.getElementById('stats').style.display = 'none';
    } finally {
        document.getElementById('loading').style.display = 'none';
    }
}


// Evento para enviar mensaje con Enter
document.getElementById('userInput').addEventListener('keypress', function(e) {
    if (e.key === 'Enter') {
        sendMessage();
    }
});
